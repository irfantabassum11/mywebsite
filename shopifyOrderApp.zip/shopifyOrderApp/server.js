const Fastify = require("fastify"); 
const fastifyFormbody = require("@fastify/formbody");
const fastifyStatic   = require("@fastify/static");
const path = require('path');
const ConnectDB = require('./config/db.js');
const routes    = require("./routes/product.routes.js");
require('dotenv').config()
ConnectDB();
const app = Fastify(); 


app.register(fastifyFormbody);

app.register(fastifyStatic, {

  root: path.join(__dirname, "public"),
  prefix: "/",

});

app.register(routes);
const start = async () => {
  try {
    await app.listen({ port: 3001, host: '127.0.0.1' });
    console.log("🚀 Server listening on http://127.0.0.1:3001");
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
};


start();





