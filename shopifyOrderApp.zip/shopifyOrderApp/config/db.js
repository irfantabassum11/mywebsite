// const mongoose = require("mongoose");
// require('dotenv').config()  
// const URI = process.env.URI
// const ConnectDB = async () => {
// try {
//         await mongoose.connect(URI);
//         console.log("DB connected successfully");
// } catch (error) {
//     console.log("Failed to connect to MongoDB");
// }
// }

// module.exports = ConnectDB;

const mongoose = require("mongoose");
require('dotenv').config();

const URI = process.env.URI;

const ConnectDB = async () => {
  try {
    await mongoose.connect(URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("✅ DB connected successfully");
  } catch (error) {
    console.error("❌ Failed to connect to MongoDB", error.message);
    process.exit(1); // 🔴 stop app if DB connection fails
  }
};

module.exports = ConnectDB;

