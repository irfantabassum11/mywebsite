const mongoose = require('mongoose');

// Define schemas for line items, customer, address, etc.
const MoneySchema = new mongoose.Schema({
  amount: String,
  currency_code: String,
}, { _id: false });

const AddressSchema = new mongoose.Schema({
  first_name: String,
  last_name: String,
  address1: String,
  address2: String,
  city: String,
  province: String,
  country: String,
  zip: String,
  phone: String,
  name: String,
  country_code: String,
  province_code: String,
}, { _id: false });

const LineItemSchema = new mongoose.Schema({
  product_id: Number,
  variant_id: Number,
  title: String,
  quantity: Number,
  sku: String,
  vendor: String,
  price: String,
  total_discount: String,
  requires_shipping: Boolean,
}, { _id: false });

const CustomerSchema = new mongoose.Schema({
  id: Number,
  email: String,
  first_name: String,
  last_name: String,
  created_at: Date,
  updated_at: Date,
  phone: String,
  currency: String,
  default_address: AddressSchema,
}, { _id: false });

const OrderSchema = new mongoose.Schema({
  orderId: { type: Number, required: true, unique: true },
  order_number: Number,
  name: String,
  email: String,
  contact_email: String,
  financial_status: String,
  fulfillment_status: String,
  total_price: String,
  subtotal_price: String,
  total_tax: String,
  currency: String,
  created_at: Date,
  updated_at: Date,
  processed_at: Date,
  customer: CustomerSchema,
  shipping_address: AddressSchema,
  billing_address: AddressSchema,
  line_items: [LineItemSchema],
  note: String,
  tags: String,
  source_name: String,
  order_status_url: String,
  rawData: { type: mongoose.Schema.Types.Mixed, required: true },
}, { timestamps: true });

const order = mongoose.model('Order', OrderSchema);
module.exports = order
