const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  parent_sku: String,
  parent_name: String,
  categories: String,
  sub_categories: String,
  description: String,
  material: String,
  capacity: String,
  dimensions: String,
  package_height: String,
  package_length: String,
  package_width: String,
  gross_weight: String,
  net_weight: String,
  pieces_per_box: String,
  pieces_per_inner: String,
  individual_box: String,
  inners_per_box: String,
  weight_unit: String,
  volume_unit: String,
  printing_technique: String,
  printing_area: String,
  parent_images: String,
  vector_images: String,
  updated_at: String,
  variant_sku: String,
  variant_name: String,
  color: String,
  price: String,
  type: String,
  currency: String,
  size: String,
  variant_images: String,
  product_id: String,
  status: String,
  warehouse: String,
  stock: {
    type: String,
    default: "nothing"
  },
  proudctId: {
    type: String,
    default: "nothing"
  },
  inventoryItemId: {
    type: String,
    default: "nothing"
  },
  variantId: {
    type: String,
    default: "nothing"
  },
  syncStatus: {
    type: String,
    default: "pending"
  },
  stockStatus: {
    type: String,
    default: "pending"
  }

});

const Product = mongoose.model('Product', ProductSchema);
module.exports = Product;
