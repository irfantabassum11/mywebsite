const {syncProduct,fetch_all_products,resetSyncedProducts,getInventoryData,getStock,products,productsFetch, getProducts, syncProductsToShopify, updateStockRandomly} = require("../controllers/product.contr.js");
const {createOrder} = require("../controllers/order.controller.js");

async function routes(app, options) {  
    app.get("/", (request, reply) => {
        return { message: "It is working" };
    });

   app.get("/getStock", getStock);
   app.get("/products",products)
   app.get("/productsFetch",productsFetch);
   app.get("/getProducts", getProducts);
   app.get("/sync", syncProductsToShopify);
   app.get("/update_db", updateStockRandomly);
   app.get("/getInventoryData",getInventoryData);
   app.get("/resetSyncedProducts",resetSyncedProducts);
    app.post("/get_order", createOrder);
    app.get("/get_order", async (req, reply) => {
  reply.send({ message: "GET route for /get_order is working!" });
});

   app.get("/fetch_all_products",fetch_all_products);
   app.post("/syncProduct",syncProduct)

}

module.exports = routes;
