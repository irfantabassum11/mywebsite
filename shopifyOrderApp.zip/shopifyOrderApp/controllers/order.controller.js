// controllers/orderController.js
const Order = require("../models/order.model");

const createOrder = async (req, reply) => {
  try {
    const orderArray = req.body;

    // Ensure the payload is an array with at least one order object
    if (!Array.isArray(orderArray) || orderArray.length === 0) {
      return reply.code(400).send({ message: "Invalid order data format." });
    }

    const shopifyOrderData = orderArray[0]; // Extract the first order in the array

    // Defensive check
    if (!shopifyOrderData.id) {
      return reply.code(400).send({ message: "Missing order ID." });
    }

    const existingOrder = await Order.findOne({ orderId: shopifyOrderData.id });
    if (existingOrder) {
      return reply.code(200).send({ message: "Order already exists." });
    }

    const newOrder = new Order({
      orderId: shopifyOrderData.id,
      order_number: shopifyOrderData.order_id?.id ?? null,
      name: shopifyOrderData.name,
      email: shopifyOrderData.customer?.email || shopifyOrderData.email,
      financial_status: shopifyOrderData.status || "unknown",
      fulfillment_status: shopifyOrderData.fulfillment_status || "unfulfilled",
      total_price: shopifyOrderData.total_price,
      subtotal_price: shopifyOrderData.subtotal_price,
      total_tax: shopifyOrderData.total_tax,
      currency: shopifyOrderData.currency,
      created_at: new Date(shopifyOrderData.created_at),
      updated_at: new Date(shopifyOrderData.updated_at),
      processed_at: new Date(shopifyOrderData.completed_at || shopifyOrderData.created_at),
      customer: shopifyOrderData.customer,
      shipping_address: shopifyOrderData.shipping_address,
      billing_address: shopifyOrderData.billing_address,
      line_items: [shopifyOrderData.line_items], // Note: Wrapped as array
      note: shopifyOrderData.note,
      tags: shopifyOrderData.tags,
      source_name: shopifyOrderData.source_name,
      order_status_url: shopifyOrderData.invoice_url || null,
      rawData: shopifyOrderData
    });

    await newOrder.save();
    console.log("✅ Order saved:", shopifyOrderData.id);

    return reply.code(201).send({ message: "Order saved successfully." });

  } catch (error) {
    console.error("❌ Error saving Shopify order:", error);
    return reply.code(500).send({ message: "Internal server error" });
  }
};

module.exports = { createOrder };
