require('dotenv').config()  
const axios   = require("axios");
const Product = require("../models/product.models.js");
const getAccessToken = require('../controllers/token.js');
const Token = require('../models/Token.js');
const clientSecret = 'fdsa0fasgadas7d0fg07adfasd0fdas7f7g6asd5';
const username = 'sadiaIsmail';
const password = 'S54dsgthGGAA';
const BASE_URL = "https://beclixretail.online/ahmad_dev/beclixTestApi";

const getProducts = async (request, reply)=>{
    try {
        const accessToken = await getAccessToken();
        const response = await axios.post(`${BASE_URL}/products.php`,
            {
                accessToken,
                clientSecret
            }
        );

        const data = response.data.products
        
        const saveProducts = await Product.insertMany(data);
        if(saveProducts){
            console.log("saved")
        }
    } catch (error) {
        console.error('error created products:',error.message);

    }
}


const getStock = async (request, reply)=>{
    try {
        const accessToken = await getAccessToken();
        const response = await axios.post(`${BASE_URL}/stock.php`,
            {
                clientSecret,
                accessToken
            }
        );

        const stockArray = response.data.stock;
        const updates = [];
        
        for (const { parent_sku, stock } of stockArray) {
          try {
            const updatedProduct = await Product.findOneAndUpdate(
              { parent_sku },
              { $set: { stock } },
              { new: true }
            );
        
            updates.push(updatedProduct);
          } catch (err) {
            console.error(`Error updating product with SKU ${parent_sku}:`, err.message);
          }
        }
        
           return reply.send({ message: 'Stock updated', product: updates });

    } catch (error) {
        console.error('error created products:',error.message);
    }
}


const updateStockRandomly = async () => {
    try {
      const products = await Product.find(); 
  
      for (const product of products) {
        const randomStock = Math.floor(Math.random() * 1000) + 1;
  
        await Product.updateOne(
          { _id: product._id },
          { $set: { stock: randomStock } }
        );
      }
  
      console.log("Stock updated with random values.");
    } catch (error) {
      console.error("Error updating stock:", error.message);
    }
  };



const products = async (request,reply)=>{
    return reply.send('home.html');
}
const productsFetch = async(request,reply)=>{
    try {
        const products = await Product.find();
        if(!products){
            reply.send({message:'products not found'});
        }
        return reply.send(products);
        
    } catch (error) {
        console.error({message:'products not found'});
        
    }
    
}

const storeId = "zayan-ch";
const shopifyAccessToken = "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";

const sanitizeAlphabets = (input) => {
    return new TextDecoder('utf-8').decode(new TextEncoder().encode(String(input)));
};


 const syncProductsToShopify = async (request, reply) => {
  try {
    const limit =10;
    const pendingParents = await Product.aggregate([
      { $match: { syncStatus: 'pending' } },
      { $group: { _id: "$parent_sku", doc: { $first: "$$ROOT" } } },
      { $limit: limit },
    ]);

    const url = `https://${storeId}.myshopify.com/admin/api/2024-01/products.json`;

    for (const parent of pendingParents) {
      const parentRow = parent.doc;
    
      const category        = sanitizeAlphabets(parentRow.categories || "");
      const description     = sanitizeAlphabets(parentRow.description || "");
      const material        = sanitizeAlphabets(parentRow.material || "");
      const dimensions      = sanitizeAlphabets(parentRow.dimensions || "");
      const title           = sanitizeAlphabets(parentRow.parent_name || "");
      const printing_tech   = sanitizeAlphabets(parentRow.printing_technique || "");
      const printing_area   = sanitizeAlphabets(parentRow.printing_area || "");
      const parentSku       = parentRow.parent_sku;
    
      const variantsDocs = await Product.find({ parent_sku: parentSku, syncStatus: 'pending' });
    
      let variants = [], colors = [], sizes = [], final_img = [];
    
      // Parent images
      const parentImages = (parentRow.parent_images || '').split(',');
      parentImages.forEach(img => final_img.push({ src: img.trim() }));
    
      for (const variant of variantsDocs) {
        const variantData = {
          option1: variant.color,
          option2: variant.size || "",
          price: variant.price,
          sku: variant.variant_sku,
          inventory_management: "shopify",
          // ❌ don't send inventory_quantity here
        };
    
        if (variant.size) {
          if (!sizes.includes(variant.size)) sizes.push(variant.size);
        }
    
        variants.push(variantData);
        if (!colors.includes(variant.color)) colors.push(variant.color);
    
        (variant.variant_images || '').split(',').forEach(img => {
          final_img.push({ src: img.trim() });
        });
      }
    
      // Vector images
      (parentRow.vector_images || '').split(',').forEach(img => {
        final_img.push({ src: img.trim() });
      });
    
      const productData = {
        product: {
          title,
          body_html: `
            <h3>Descripcion y Characteristicas</h3><strong>${description}</strong><br><br>
            <h3>Informacion Basica</h3><strong>Categoria:</strong> ${category}<br>
            <strong>Material:</strong> ${material}<br>
            <strong>Dimensiones:</strong> ${dimensions}<br>
            <strong>Peso Bruto:</strong> ${parentRow.gross_weight} ${parentRow.weight_unit}<br>
            <strong>Peso Neto:</strong> ${parentRow.net_weight} ${parentRow.weight_unit}<br>
            <h3>Información de impresión</h3><strong>Técnica de Impresión:</strong> ${printing_tech}<br>
            <strong>Área de Impresión:</strong> ${printing_area}<br>
            <h3>Informacion de Empaque</h3><strong>Medidas:</strong> ${parentRow.package_height} x ${parentRow.package_length} x ${parentRow.package_width} cm<br>
            <strong>Peso:</strong> ${parentRow.gross_weight}<br>
            <strong>Caja Individual:</strong> SI<br>
            <strong>Cantidad de Piezas:</strong> ${parentRow.pieces_per_box}<br>
          `,
          vendor: "Zayan",
          product_type: category,
          status: "active",
          variants,
          options: [
            { name: "COLOR", values: colors },
            ...(sizes.length ? [{ name: "SIZE", values: sizes }] : [])
          ],
          images: final_img
        }
      };
    
      // ✅ Send to Shopify
      const shopifyResponse = await axios.post(url, productData, {
        headers: {
          "Content-Type": "application/json",
          "X-Shopify-Access-Token": shopifyAccessToken
        }
      });
    
      const createdProduct = shopifyResponse.data.product;
    
      // ✅ Update MongoDB
      for (const variant of createdProduct.variants) {
        const result = await Product.updateMany(
          { variant_sku: variant.sku },
          {
            $set: {
              variantId: variant.id,
              inventoryItemId: variant.inventory_item_id,
              proudctId: createdProduct.id,
              syncStatus: "synced"
            }
          }
        );
        console.log(`Matched: ${result.matchedCount}, Modified: ${result.modifiedCount}`);
      }
    }
    

    return reply.send({ status: 200, message: 'Products uploaded and database updated successfully' });

  } catch (error) {
    console.error(error);
    return reply.status(500).send({ status: 500, error: error.message });
  }
};


const updateInventory = async (req, reply) => {
  let successCount = 0;
  let errorCount = 0;
  let responseList = [];

  try {
    const products = await Product.find({
      syncStatus: "Synced",
      stcokStatus: "pending"
    }).limit(25);

    if (products.length === 0) {
      return reply.send({
        success: false,
        message: 'No products to update'
      });
    }

    for (const product of products) {
      const { ProductId, inventoryItemId, inventoryLevel } = product;

      if (inventoryLevel !== null && inventoryLevel !== undefined) {
        try {
          const payload = {
            location_id: LOCATION_ID,
            inventory_item_id: inventoryItemId,
            available: inventoryLevel
          };

          const response = await axios.post(`${SHOPIFY_URL}/inventory_levels/set.json`, payload, {
            headers: {
              'Content-Type': 'application/json',
              'X-Shopify-Access-Token': storeAccessToken
            }
          });
console.log(response.data)
          if (response.data.inventory_level) {
            await Product.updateOne(
              { ProductId },
              { $set: { stcokStatus: 'synced' } }
            );

            successCount++;
            responseList.push({
              sku: ProductId,
              status: 'Success',
              remarks: 'Product has been synced'
            });
          } else {
            await Product.updateOne(
              { ProductId },
              { $set: { stcokStatus: 'API Error' } }
            );

            errorCount++;
            responseList.push({
              sku: ProductId,
              status: 'Error',
              remarks: 'API Error'
            });
          }
        } catch (error) {
          await Product.updateOne(
            { ProductId },
            { $set: { stcokStatus: 'API Error' } }
          );

          errorCount++;
          responseList.push({
            sku: ProductId,
            status: 'Error',
            remarks: error.response?.data || error.message
          });
        }
      } else {
        await Product.updateOne(
          { ProductId },
          { $set: { stcokStatus: 'Inventory Not Found' } }
        );

        errorCount++;
        responseList.push({
          sku: ProductId,
          status: 'Error',
          remarks: 'Inventory Not Found'
        });
      }
    }

    return reply.send({
      success: successCount,
      error: errorCount,
      list: responseList
    });
  } catch (error) {
    console.error('Error fetching products:', error.message);
    return reply.status(500).send({ error: 'Failed to update inventory levels.' });
  }
};

const shop = 'zayan-ch.myshopify.com';
const accessToken = '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';
const location_id = 104502329628;

const updateShopifyStock = async (products) => {
  for (const item of products) {
    const payload = {
      location_id: location_id,
      inventory_item_id: item.inventoryItemId,
      available: item.stock
    };

    try {
      const shopify_response = await axios.post(
        `https://${shop}/admin/api/2024-01/inventory_levels/set.json`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
            'X-Shopify-Access-Token': accessToken
          }
        }
      );

      console.log('✅ Shopify Response:', shopify_response.data);

      // ✅ Step 1: Mark product as "synced" after successful update
      await Product.updateOne(
        { inventoryItemId: item.inventoryItemId },
        { $set: { stockStatus: 'synced' } }
      );

    } catch (error) {
      console.error(`❌ Failed to update item ${item.inventoryItemId}:`, error.response?.data || error.message);
    }
  }

  // ✅ Step 2: Check if all products are now "synced"
  const pendingProducts = await Product.countDocuments({ stockStatus: { $ne: 'synced' } });

  if (pendingProducts === 0) {
    console.log('✅ All products synced! Resetting stockStatus to "pending"...');

    // ✅ Step 3: Reset all stockStatus to "pending"
    const result = await Product.updateMany(
      {},
      { $set: { stockStatus: 'pending' } }
    );

    console.log(`🔄 Reset ${result.modifiedCount} products back to 'pending'.`);
  }
};


const getInventoryData = async (request, reply) => {
  try {
    const products = await Product.find(
      { syncStatus: 'synced' },
      { inventoryItemId: 1, stock: 1, _id: 0 }
    );

    
    // return(products)

    await updateShopifyStock(products);

    reply.send({ message: 'Stock update completed successfully!' });
  } catch (error) {
    console.error('Error:', error.message);
    reply.status(500).send({ error: 'Stock sync failed.' });
  }
};

const resetSyncedProducts = async () => {
  try {
    const result = await Product.updateMany(
      {syncStatus:'synced' },
      { $set: {syncStatus: 'pending' } }
    );
    console.log(`${result.modifiedCount} products reset to 'pending'.`);
  } catch (error) {
    console.error('Failed to reset statuses:', error);
  }
};

const fetch_all_products = async (req, reply) => {
  try {
    const products = await Product.find({});
    reply.send(products);
  } catch (err) {
    reply.status(500).send({ message: 'Error fetching products' });
  }
};

const syncProduct = async (req, reply) => {
  const product = req.body;

  try {
    const shop = 'zayan-ch.myshopify.com';
    const accessToken = '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';
    const apiVersion = '2023-10';

    const shopifyProduct = {
      product: {
        title: product.parent_name,
        body_html: product.description || '',
        vendor: "irfan",
        product_type: product.categories || 'Default',
        status: 'active',
        images: [
          { src: product.parent_images }
        ],
        variants: [
          {
            option1: product.color || 'Default',
            price: product.price || '0.00',
            sku: product.variant_sku,
            inventory_quantity: parseInt(product.stock) || 0,
            inventory_management: 'shopify'
          }
        ],
        options: [
          {
            name: "Color",
            values: [product.color || 'Default']
          }
        ]
      }
    };

    const response = await axios.post(
      `https://${shop}/admin/api/${apiVersion}/products.json`,
      shopifyProduct,
      {
        headers: {
          'X-Shopify-Access-Token': accessToken,
          'Content-Type': 'application/json'
        }
      }
    );

    const createdProduct = response.data.product;

    for (const variant of createdProduct.variants) {
      const result = await Product.updateMany(
        { variant_sku: variant.sku },
        {
          $set: {
            variantId: variant.id,
            inventoryItemId: variant.inventory_item_id,
            proudctId: createdProduct.id,
            syncStatus: "synced"
          }
        }
      );
      console.log(`Matched: ${result.matchedCount}, Modified: ${result.modifiedCount}`);
    }

   
    reply.send({
      message: '✅ Product synced successfully!',
      shopifyProductId: createdProduct.id,
      variantId: createdProduct.variants[0].id,
      status: 'success'
    });

  } catch (error) {
    console.error("❌ Shopify sync failed:", error.response?.data || error.message);
    reply.status(500).send({
      message: '❌ Sync failed',
      error: error.response?.data || error.message,
      status: 'error'
    });
  }
};


module.exports = {fetch_all_products,syncProduct,resetSyncedProducts,getInventoryData, getStock, products, productsFetch, getProducts, syncProductsToShopify, updateStockRandomly };