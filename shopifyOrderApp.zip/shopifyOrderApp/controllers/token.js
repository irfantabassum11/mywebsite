const axios = require('axios');
const Token = require('../models/Token.js');
const clientSecret = 'fdsa0fasgadas7d0fg07adfasd0fdas7f7g6asd5';
const username = 'sadiaIsmail';
const password = 'S54dsgthGGAA';
const BASE_URL = 'https://beclixretail.online/ahmad_dev/beclixTestApi';

const refreshAccessToken = async () => {
  try {
    const token = await Token.findOne({});

    if (!token) {
      console.error('No token found in the database');
      return null;
    }

    const { accessToken, refreshToken } = token;

    const response = await axios.post(`${BASE_URL}/refresh_token.php`, {
      username,
      password,
      clientSecret,
      refreshToken,
      accessToken

    });
    console.log("response", response.data);
    

    if (response.status === 200) {
      const { accessToken , expiresAt } = response.data;


      await Token.findOneAndUpdate(
        {
          $set: {
            accessToken: accessToken,
            expiresAt: new Date(expiresAt)
          }
        },
        { upsert: true, new: true }
      );

      console.log('Token refreshed successfully:', accessToken);
      return accessToken;
    } else {
      console.error('Failed to refresh token: Unexpected response status', response.status);
      return null;
    }
  } catch (error) {
    console.error(
      'Failed to refresh token:',
      error.response ? error.response.data : error.message
    );
    return null;
  }
};

const isTokenExpired = async () => {
  try {

    const token = await Token.findOne({});
    if (!token) {
      console.log('No token found, refreshing...');
      await refreshAccessToken();
      return true;
    }

    const now = new Date();
    const expired = now >= token.expiresAt;

    console.log(`Token expired: ${expired}`);

    if (expired) {
      console.log('Token is expired, refreshing...');
      await refreshAccessToken();
      return true;
    }

    return false;
  } catch (error) {
    console.error('Failed to check token expiration:', error.message);
    return true;
  }
};

const getAccessToken = async () => {
    const expired = await isTokenExpired();
  
    if (expired) {
      console.log('Refreshing token...');
      const refreshedToken = await refreshAccessToken();
      return refreshedToken;
    }
  
    const token = await Token.findOne({});
    return token ? token.accessToken : null;
  };
  



const getToken = async(request, reply)=>{
    const respnse = await axios.post(`${BASE_URL}/auth.php`,{
        username,
        password,
        clientSecret
    })
    const data = respnse.data
    await Token.create(data);
}


module.exports = getAccessToken;